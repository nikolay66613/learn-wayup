let city='Moscow';
let country='Russia';
let population=12636312;
let stadium=true;

console.log (city,country,population,stadium)

//задание 2. опрделение площади прямоугольника

let heightRect=40;
let widthRect=70;
let result=heightRect*widthRect;
console.log (result)

//Задание 3. Определение расстоняия.

let time=2;
	speedOfFirst=95;
	speedOfSecond=114

let result2=((time*speedOfSecond)+(time*speedOfFirst));

console.log(result2);

//Задание 4.
const randomNumber = Math.floor(Math.random() * 100);
if (randomNumber<20) {console.log("randomNumber меньше 20")}
else if (randomNumber>50){console.log("randomNumber больше 50")}
else if (randomNumber>20,randomNumber<50){console.log("randomNumber больше 20, и меньше 50")}

// Задание 5.

const randomNumber1 = Math.floor(Math.random() * 100);
switch (randomNumber1) {
	case randomNumber1<20:
		console.log("randomNumber меньше 20")
	case (randomNumber1>50):
		console.log("randomNumber больше 50")
	case (randomNumber1>20,randomNumber<50):
		console.log("randomNumber больше 20, и меньше 50")
}